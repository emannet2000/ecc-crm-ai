module northwind

go 1.26.0

require (
	github.com/golang-jwt/jwt/v5 v5.3.1
	golang.org/x/crypto v0.57.0
)
